<li class="panel-marks"><a href="/marks"><?php echo _('All Marks') ?></a></li>
<li class="panel-label"><a rel="200" href="#panel-label"><?php echo _('Labels') ?></a></li>
<li class="panel-timeline"><a rel="250" href="#panel-timeline"><?php echo _('Timeline') ?></a></li>
<li class="panel-search"><a rel="350" href="#panel-search"><?php echo _('Search') ?></a></li>
<li class="panel-search"><a href="/marks/archive"><?php echo _('Archives') ?></a></li>
