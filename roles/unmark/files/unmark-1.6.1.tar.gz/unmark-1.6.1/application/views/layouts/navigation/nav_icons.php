<div class="menu-activator menu-item"><a alt="<?php echo _('View/Hide Menu'); ?>" rel="200" href="#panel-menu"><i class="icon-menu_open"></i></a></div>
<div class="menu-marks menu-item"><a alt="<?php echo _('View All Marks'); ?>" href="/marks"><i class="icon-links"></i></a></div>
<div data-menu="panel-label" class="menu-labels menu-item"><a alt="<?php echo _('View Labels'); ?>" rel="200" href="#panel-label"><i class="icon-label"></i></a></div>
<div data-menu="panel-timeline" class="menu-timeline menu-item"><a alt="<?php echo _('View Timeline'); ?>" rel="250" href="#panel-timeline"><i class="icon-time"></i></a></div>
<div data-menu="panel-search" class="menu-search menu-item"><a alt="<?php echo _('Search &amp; Tags'); ?>" rel="350" href="#panel-search"><i class="icon-search"></i></a></div>
<div data-menu="panel-archives" class="menu-archive menu-item"><a alt="<?php echo _('View Archive'); ?>" href="/marks/archive"><i class="icon-archive"></i></a></div>
<div data-menu="panel-settings" class="menu-settings menu-item"><a alt="<?php echo _('Settings'); ?>" rel="350" href="#panel-settings"><i class="icon-settings"></i></a></div>
