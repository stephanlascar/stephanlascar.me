            </div>
            <div class="sidebar-content"><?php $this->load->view('layouts/sidebar'); ?></div>
        </div>
    </div> <!-- end main-wrapper -->
</div> <!-- end unmark-wrapper -->

<?php $this->load->view('layouts/footer_scripts')?>

</body>
</html>