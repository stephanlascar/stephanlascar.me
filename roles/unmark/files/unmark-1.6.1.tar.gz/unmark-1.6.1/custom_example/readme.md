## Custom Directory
Please go [here](https://github.com/plainmade/nilai/wiki/Custom) to read more about this.